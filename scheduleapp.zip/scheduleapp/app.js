const server = require('http').createServer();
const io=require('socket.io')(server);

io.on('connection',function(socket)

{console.log('coonected to client');
socket.on('disconnect',function()
{
    console.log('gg');
}

)

}

)
server.listen(5000);