<?php 

class Database{
    private $host='localhost';
    private $user='root';
    private $pass='';
    private $dbname='dspro_db';

    public function connect()
    {
        $connection_str='mysql:host='.$this->host.';dbname='.$this->dbname;

        $db=new PDO($connection_str,$this->user,$this->pass);
        $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        return $db;
    }
}