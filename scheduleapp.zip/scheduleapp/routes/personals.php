<?php 
   if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

    exit(0);
}



use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;




$config = ['settings' => ['displayErrorDetails' => true]]; 

$app = new \Slim\App($config);
$app->get('/personals',function(Request $request,Response $response){
    $db= new Database();
    try{
        $sql='Select * from personals';
        $connected=$db->connect();
        $query=$connected->query($sql);
        $allPersonals=$query->fetchAll(PDO::FETCH_OBJ);
      
           return $response
                ->withStatus(200)
                ->withHeader('Content-Type','application/json')
                ->withHeader('Access-Control-Allow-Origin','*')
                ->withHeader('Access-Control-Allow-Methods','GET,PUT,POST,DELETE,PATCH,OPTIONS')
                ->withJson($allPersonals);
         }
    catch(PDOException $e)
    {
        return $response->withJson(
            array(
                "error"=> array(
                    "text"=>$e->getMessage(),
                    "code"=> $e->getCode())));}
$db=null;
});
$app->post('/personals/login',function(Request $request,Response $response){
    $username=$request->getParam("username");
    $password=$request->getParam("password");
    $db= new Database();
    try{
        $sql='Select * from personals where username=? and password=?';
        $connected=$db->connect();
        $query=$connected->prepare($sql);
        $query->bindParam(1,$username);
        $query->bindParam(2,$password);
        $query->execute();
        $return=$query->fetch(PDO::FETCH_OBJ);
      
           return $response
                ->withStatus(200)
                ->withHeader('Content-Type','application/json')
                ->withJson($return);
         }
    catch(PDOException $e)
    {
        return $response->withJson(
            array(
                "error"=> array(
                    "text"=>$e->getMessage(),
                    "code"=> $e->getCode())));}
$db=null;
});
//Get all approved jobs
$app->get('/schedule/all',function(Request $request,Response $response){
    
    $db= new Database();
    try{
        $sql='Select * from approved_schedule ';
        $connected=$db->connect();
        $query=$connected->prepare($sql);
        $query->execute();
        $return=$query->fetchAll(PDO::FETCH_OBJ);
      
           return $response
                ->withStatus(200)
                ->withHeader('Content-Type','application/json')
                ->withJson($return);
         }
    catch(PDOException $e)
    {
        return $response->withJson(
            array(
                "error"=> array(
                    "text"=>$e->getMessage(),
                    "code"=> $e->getCode())));}
$db=null;
});
//get all job requests (for admin)
$app->get('/schedule/admin/requests',function(Request $request,Response $response){
    
    $db= new Database();
    try{
        $sql='Select * from request_schedule';
        $connected=$db->connect();
        $query=$connected->prepare($sql);
        $query->execute();
        $return=$query->fetch(PDO::FETCH_OBJ);
      
           return $response
                ->withStatus(200)
                ->withHeader('Content-Type','application/json')
                ->withJson($return);
         }
    catch(PDOException $e)
    {
        return $response->withJson(
            array(
                "error"=> array(
                    "text"=>$e->getMessage(),
                    "code"=> $e->getCode())));}
$db=null;
});



//get worker's job by worker 
$app->get('/schedule/worker/approvedjob',function(Request $request,Response $response){
    $username=$request->getParam('username');
    
    $db= new Database();
    try{
        $sql='Select * from approved_schedule where username=?';
        $connected=$db->connect();
        $query=$connected->prepare($sql);
        $query->bindParam(1,$username);
        $query->execute();
        $return=$query->fetch(PDO::FETCH_OBJ);
      
           return $response
                ->withStatus(200)
                ->withHeader('Content-Type','application/json')
                ->withJson($return);
         }
    catch(PDOException $e)
    {
        return $response->withJson(
            array(
                "error"=> array(
                    "text"=>$e->getMessage(),
                    "code"=> $e->getCode())));}
$db=null;
});
//New job insert 
$app->post('/schedule/worker/addrequest',function(Request $request,Response $response){
    $username=$request->getParam('username');
    $requestedJobName=$request->getParam('requestedJobName');
    
    $db= new Database();
    try{
        $uniquejobid=$requestedJobName.time();
        $sql='Insert into request_schedule (request_job_name,request_job_unique_id,request_job_worker_uname) values(?,?,?)';
        $connected=$db->connect();
        $query=$connected->prepare($sql);
        $query->bindParam(1,$requestedJobName);
        $query->bindParam(2,$uniquejobid);
        $query->bindParam(3,$username);
        
        if($query->execute())
        {
            return $response
            ->withStatus(200)
            ->withHeader('Content-Type','application/json')
            ->withJson('Job Request Sent with Success...');
        }
        else{
            return $response
            ->withStatus(200)
            ->withHeader('Content-Type','application/json')
            ->withJson('There was an error occuried...');
        }
      
           
         }
    catch(PDOException $e)
    {
        return $response->withJson(
            array(
                "error"=> array(
                    "text"=>$e->getMessage(),
                    "code"=> $e->getCode())));}
$db=null;
});
$app->post('/schedule/admin/response/accept',function(Request $request,Response $response){
    $requestjobuniqueid=$request->getParam('requestJobUniquesID');
    $db= new Database();
    try{
        
        
            $admin='admin';
            $sqlGetJob='Select * from request_schedule where request_job_unique_id=?';
            $connected=$db->connect();

            $queryGetJob=$connected->prepare($sqlGetJob);
            $queryGetJob->bindParam(1,$requestjobuniqueid);
            $queryGetJob->execute();
            $gettingJob=$queryGetJob->fetch(PDO::FETCH_ASSOC);
            $sqlinsertJob='insert into approved_schedule (approved_job_name,approved_job_unique_id,approved_job_worker,approved_job_approver_admin_uname) values(?,?,?,?)';
            $query=$connected->prepare($sqlinsertJob);
            $query->bindParam(1,$gettingJob['request_job_name']);
            $query->bindParam(2,$gettingJob['request_job_unique_id']);
            $query->bindParam(3,$gettingJob['request_job_worker_uname']);
            $query->bindParam(4,$admin);

            
            if($query->execute())
            {
                $sqlLast='Delete  from request_schedule where request_job_unique_id=?';
                $connected=$db->connect();
                $queryLast=$connected->prepare($sqlLast);
                $queryLast->bindParam(1,$requestjobuniqueid);
                $queryLast->execute();
              
                    return $response
                    ->withStatus(200)
                    ->withHeader('Content-Type','application/json')
                    ->withJson('Job has been approved...');
                
                   

            }

            
            


        
        $sqlLast='Delete * from request_schedule where request_job_unique_id=?';
        $connected=$db->connect();

        $queryLast=$connected->prepare($sqlLast);
        $queryLast->bindParam(1,$requestjobuniqueid);
        $queryLast->execute();
      
        
        
        
           
         }

    catch(PDOException $e)
    {
        return $response->withJson(
            array(
                "error"=> array(
                    "text"=>$e->getMessage(),
                    "code"=> $e->getCode())));}
$db=null;
});
$app->post('/schedule/admin/response/decline',function(Request $request,Response $response){
    $requestjobuniqueid=$request->getParam('requestJobUniquesID');
    $db= new Database();
    try{
        
        
            

        
        $sqlLast='Delete from request_schedule where request_job_unique_id=?';
        $connected=$db->connect();

        $queryLast=$connected->prepare($sqlLast);
        $queryLast->bindParam(1,$requestjobuniqueid);
        $queryLast->execute();
      
        
        
        
           
         }

    catch(PDOException $e)
    {
        return $response->withJson(
            array(
                "error"=> array(
                    "text"=>$e->getMessage(),
                    "code"=> $e->getCode())));}
$db=null;
});